import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [assets, setAssets] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('http://localhost:5000/api/assets')
      .then(res => res.json())
      .then(data => setAssets(data))
      .catch(err => console.error('Error fetching assets:', err));
  }, []);

  const filteredAssets = assets.filter(asset => 
    asset.asset_tag.toLowerCase().includes(search.toLowerCase()) ||
    asset.serial_number.toLowerCase().includes(search.toLowerCase()) ||
    asset.brand_model.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">IT Asset Management System</h1>
            <p className="text-gray-600">Track hardware, serial numbers, and department assignments</p>
          </div>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700">
            + Add New Asset
          </button>
        </header>

        <div className="bg-white rounded-xl shadow p-6 mb-6">
          <input
            type="text"
            placeholder="Search by Asset Tag, Serial Number, or Model..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="bg-white rounded-xl shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset Tag</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Brand & Model</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Serial Number</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredAssets.length > 0 ? (
                filteredAssets.map(asset => (
                  <tr key={asset.asset_id}>
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{asset.asset_tag}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">{asset.category}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">{asset.brand_model}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500 font-mono text-sm">{asset.serial_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">{asset.department_name || 'Unassigned'}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        asset.status === 'Available' ? 'bg-green-100 text-green-800' :
                        asset.status === 'Assigned' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {asset.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center text-gray-500">No assets found or backend server disconnected.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App;
