const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

// Database connection pool
const db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'it_asset_db',
    waitForConnections: true,
    connectionLimit: 10
});

// Test connection
db.getConnection((err, connection) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL database as ID ' + connection.threadId);
    connection.release();
});

// GET all assets
app.get('/api/assets', (req, res) => {
    const query = `
        SELECT a.*, d.department_name, u.full_name as assigned_user 
        FROM assets a 
        LEFT JOIN departments d ON a.department_id = d.department_id 
        LEFT JOIN users u ON a.assigned_user_id = u.user_id
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// POST new asset
app.post('/api/assets', (req, res) => {
    const { asset_tag, category, brand_model, serial_number, purchase_date, department_id } = req.body;
    const query = 'INSERT INTO assets (asset_tag, category, brand_model, serial_number, purchase_date, department_id) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [asset_tag, category, brand_model, serial_number, purchase_date, department_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Asset added successfully', assetId: result.insertId });
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
